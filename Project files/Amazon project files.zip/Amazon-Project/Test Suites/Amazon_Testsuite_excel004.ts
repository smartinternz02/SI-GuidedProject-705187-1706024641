<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_Testsuite_excel004</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>851d55f7-daae-4e9e-b582-718413c9796c</testSuiteGuid>
   <testCaseLink>
      <guid>827ddffd-5d89-41f1-bdbf-4794ea0a0de5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon_testcase_004</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>eac0c77d-7b79-493e-a0c2-dd246cbac65e</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_excel004</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>eac0c77d-7b79-493e-a0c2-dd246cbac65e</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Email</value>
         <variableId>8b2e1146-071e-4cd6-9e8e-41dacaa8f51b</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
