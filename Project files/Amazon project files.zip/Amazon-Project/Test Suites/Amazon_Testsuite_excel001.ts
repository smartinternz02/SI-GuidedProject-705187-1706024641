<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Amazon_Testsuite_excel001</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>4833cd6b-68dc-4b19-ae62-f3279ef0b3a0</testSuiteGuid>
   <testCaseLink>
      <guid>9db20b56-b5d3-4a9b-9902-be6faf78e008</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Amazon_testcase_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>c20fc605-708e-4704-b5ed-71943373d5b7</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Amazon_excel001</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>c20fc605-708e-4704-b5ed-71943373d5b7</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Email</value>
         <variableId>86a7f14c-8841-4e47-a045-7a9efab25fc9</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
