<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Account  Lists</name>
   <tag></tag>
   <elementGuidId>49e386da-7be4-44b6-917d-f67483f622f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#nav-link-accountList > span.nav-line-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='nav-link-accountList']/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9a8987df-5b24-45b7-b077-23381270838a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-line-2 </value>
      <webElementGuid>5619d4b9-dbbc-4583-98ab-17168203fc73</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Account &amp; Lists
  </value>
      <webElementGuid>792b330f-b1b4-4688-9eb4-a9f26f25370c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-link-accountList&quot;)/span[@class=&quot;nav-line-2&quot;]</value>
      <webElementGuid>438b37b0-88b5-4075-9fa9-bd77c4f3bbc4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='nav-link-accountList']/span</value>
      <webElementGuid>a5953483-9d97-4095-9fae-1fe7fa367d3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hello, Gopi'])[1]/following::span[1]</value>
      <webElementGuid>bf3f4d14-f37e-450f-ba68-de6bb9860888</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EN'])[1]/following::span[3]</value>
      <webElementGuid>2a6e62a4-b9b4-4016-832c-f915d82da570</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Not Gopi? Sign Out'])[1]/preceding::span[2]</value>
      <webElementGuid>64277549-148b-466a-8e0c-dd91cf559d6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Returns'])[1]/preceding::span[2]</value>
      <webElementGuid>3ca2ac14-6f61-443e-b5c8-62179dd0bf0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Account &amp; Lists']/parent::*</value>
      <webElementGuid>fd85a9c6-5da3-4075-a4c5-f7e3daeb965a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[2]/span</value>
      <webElementGuid>00ce3b51-6d60-4583-a12a-e836cad306c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Account &amp; Lists
  ' or . = 'Account &amp; Lists
  ')]</value>
      <webElementGuid>065ec7a7-5f11-43e4-8cf5-5b72bfa849ce</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
