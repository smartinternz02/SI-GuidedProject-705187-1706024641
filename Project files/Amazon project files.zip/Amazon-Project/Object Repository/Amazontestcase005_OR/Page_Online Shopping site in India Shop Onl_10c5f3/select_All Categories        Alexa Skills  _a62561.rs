<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Categories        Alexa Skills  _a62561</name>
   <tag></tag>
   <elementGuidId>2800c88c-e2a7-463d-a727-14762fb01ad4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>8b93a495-96f8-43e9-865a-ef268df9d8ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>0339134a-d8dd-4326-9221-6411dc331cc7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>2647a0e3-3e13-4adc-8a63-1bcad7b85343</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>z8P8icFxb+A7TvfQgN/euAOp8Ko=</value>
      <webElementGuid>85f0fa94-229b-4659-a1b5-d4a4d11c7b5b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>9247d8b5-e01e-4eeb-8a1f-107f4981490a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>f31712eb-9f11-4289-a537-617c4c5df05b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>0524850b-0b10-459a-9c35-5e7dccb1eaf7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>30c70248-6241-454b-848b-3ec4aac15ff0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>91d26d54-ddc2-4d45-bbfb-2214347a2e85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Fresh
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    </value>
      <webElementGuid>7becd595-9915-4038-ac2d-e8360ebf25f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>e7fb95a4-53dd-4a3e-8329-ff79e40e65e3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>12817b53-2ece-4a25-a70e-cdb1d29b2349</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>69de7d2f-ca92-46c8-a26d-fead9e25d5d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All'])[1]/following::select[1]</value>
      <webElementGuid>b5c20c27-9d12-4fe3-9032-153c29c493af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Secunderabad 500009‌'])[1]/following::select[1]</value>
      <webElementGuid>c6dd0b92-48b0-4963-bf03-0ea77c340bf3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search Amazon.in'])[1]/preceding::select[1]</value>
      <webElementGuid>dd936029-9227-4901-a0ff-221dc8f286ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EN'])[1]/preceding::select[1]</value>
      <webElementGuid>e928dc62-31db-4081-b01d-b04b2ffbf17f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>b1e8212a-73a7-4534-a37c-dd266e3eeaa0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Fresh
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ' or . = '
        All Categories
        Alexa Skills
        Amazon Devices
        Amazon Fashion
        Amazon Fresh
        Amazon Pharmacy
        Appliances
        Apps &amp; Games
        Audible Audiobooks
        Baby
        Beauty
        Books
        Car &amp; Motorbike
        Clothing &amp; Accessories
        Collectibles
        Computers &amp; Accessories
        Deals
        Electronics
        Furniture
        Garden &amp; Outdoors
        Gift Cards
        Grocery &amp; Gourmet Foods
        Health &amp; Personal Care
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Jewellery
        Kindle Store
        Luggage &amp; Bags
        Luxury Beauty
        Movies &amp; TV Shows
        Music
        Musical Instruments
        Office Products
        Pet Supplies
        Prime Video
        Shoes &amp; Handbags
        Software
        Sports, Fitness &amp; Outdoors
        Subscribe &amp; Save
        Tools &amp; Home Improvement
        Toys &amp; Games
        Under ₹500
        Video Games
        Watches
    ')]</value>
      <webElementGuid>77aa2d80-c053-4db2-a63a-57d9bc668041</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
