<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Secunderabad 500009</name>
   <tag></tag>
   <elementGuidId>4d6d54f8-d315-4329-ba56-83f6a6089ac2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#glow-ingress-line2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='glow-ingress-line2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>fd0bf6ab-7bd5-4751-a4e1-b13b89ee1288</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-line-2 nav-progressive-content</value>
      <webElementGuid>0a6b9084-79e7-4547-9ec9-f5743d8ce045</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>glow-ingress-line2</value>
      <webElementGuid>13671bf2-cf3f-46c2-9681-1d6debb6487b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                   Secunderabad 500009‌
                </value>
      <webElementGuid>4a87903f-5c3f-41fd-b1c7-a08439a2a577</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;glow-ingress-line2&quot;)</value>
      <webElementGuid>6101a8f6-53a4-4aab-bb0b-297403e12742</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//span[@id='glow-ingress-line2']</value>
      <webElementGuid>9193fa23-ba72-48eb-b17b-7b97af456b4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='glow-ingress-block']/span[2]</value>
      <webElementGuid>6734c66a-2704-4976-89df-1345cdd257f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Deliver to'])[1]/following::span[1]</value>
      <webElementGuid>353cf1ff-9f0f-45bf-8978-9a78ce98dadd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.in'])[1]/following::span[3]</value>
      <webElementGuid>6a912bb4-2de5-4d8c-a863-13ad36231fd5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All'])[1]/preceding::span[1]</value>
      <webElementGuid>bd639196-15cd-4730-8edc-49b711e0e1e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search Amazon.in'])[1]/preceding::span[2]</value>
      <webElementGuid>c057cdfe-713a-4bab-88e0-400e88fe7545</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Secunderabad 500009‌']/parent::*</value>
      <webElementGuid>f1c800f4-a1fb-4270-8f4d-67e1ea364931</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span[2]</value>
      <webElementGuid>7ac505e0-81f3-41b1-8588-b0b010d0a986</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@id = 'glow-ingress-line2' and (text() = '
                   Secunderabad 500009‌
                ' or . = '
                   Secunderabad 500009‌
                ')]</value>
      <webElementGuid>041b2204-843b-4fa7-977f-cacfa258e113</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
