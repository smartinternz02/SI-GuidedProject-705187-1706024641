<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Hyderabad 500056</name>
   <tag></tag>
   <elementGuidId>b5bdd1fc-ad86-401a-af75-5bc3f2b53ac1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#glow-ingress-line2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@id='glow-ingress-line2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7a0f2923-10e0-4a32-87e0-3ba0b6c13cc4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-line-2 nav-progressive-content</value>
      <webElementGuid>faa7717a-5d2f-4902-bc79-c2b9d7d85278</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>glow-ingress-line2</value>
      <webElementGuid>1561d937-e367-4a25-b4bb-491e264e667f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                   Hyderabad 500056‌
                </value>
      <webElementGuid>3fcfde92-224d-4ed4-990f-17e9474fd09a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;glow-ingress-line2&quot;)</value>
      <webElementGuid>0a384d03-91c3-4536-b61d-dc2b265c37dd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//span[@id='glow-ingress-line2']</value>
      <webElementGuid>0b8ce94f-b6ff-4bfb-ae15-8be95d2f920c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='glow-ingress-block']/span[2]</value>
      <webElementGuid>b0c2b65f-e3eb-4c7c-a65d-ea4d8085f713</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Deliver to'])[1]/following::span[1]</value>
      <webElementGuid>137a467c-b4c0-422a-9f5c-4f3433019d5f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='.in'])[1]/following::span[3]</value>
      <webElementGuid>76438d11-449c-440c-90d9-800b52c1763a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All'])[1]/preceding::span[1]</value>
      <webElementGuid>88134a7a-cb13-4cb4-b967-ac35430cf120</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search Amazon.in'])[1]/preceding::span[2]</value>
      <webElementGuid>b48e5752-5b60-416f-a535-8db0fc8e87d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Hyderabad 500056‌']/parent::*</value>
      <webElementGuid>50792a85-f667-48a8-9a51-5e8d80a0135c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/span[2]</value>
      <webElementGuid>3d59e346-bd03-4f6f-80ca-389fec4e04ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[@id = 'glow-ingress-line2' and (text() = '
                   Hyderabad 500056‌
                ' or . = '
                   Hyderabad 500056‌
                ')]</value>
      <webElementGuid>f39ada2d-42cb-4719-be9e-42202b19e4a3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
